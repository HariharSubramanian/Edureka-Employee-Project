import { Component } from '@angular/core';

@Component({
  selector: 'empdata-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent {
  tableName="Employees"
}
