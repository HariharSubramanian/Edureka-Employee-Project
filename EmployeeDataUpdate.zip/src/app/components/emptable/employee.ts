export interface Employee{
    empId:number,
    firstName:string,
    lastName:string,
    salary:number,
    dob:string,
    email:string,
}